//: Playground - noun: a place where people can play

import UIKit

  /************************************************************ //Velocimetro// ************************************************************/



//Declaramos la enumeración las diferentes velocidades y asignamos el valor inicial a 0, apagado.
enum Velocidades : Int{
        
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
        
    init (velocidadInicial: Velocidades){
        self = .Apagado
    }

}

//Definimos la clase Auto
class Auto{
    
    
    var velocidad  = Velocidades(velocidadInicial: Velocidades.Apagado)
    
    init(velocidad: Velocidades){
        
    }
    
    func cambioDeVelocidad(vel: Velocidades) -> (actual : Int,  velocidadEnCadena: String){
        
        //Case = 0 Apagado
        if  vel == Velocidades.Apagado {
            
            
        
            let velocidadEnCadena = "Velocidad Baja, Pisa el accelerador!"
            
            let resultado = (Velocidades.VelocidadBaja.rawValue , velocidadEnCadena)
            
            print(resultado)
            
            return resultado
            
            
        }
        
        //Case = 20 Velbaja
        if  vel == Velocidades.VelocidadBaja {
        
            
            let velocidadEnCadena = "Velocidad Media, así me gusta"
            
            let resultado = (Velocidades.VelocidadMedia.rawValue , velocidadEnCadena)
            
            print(resultado)
            
            return resultado
        
        }
        
        //Case = 50 VelMedia
        if  vel == Velocidades.VelocidadMedia {
            
            vel.rawValue == Velocidades.VelocidadAlta.rawValue
            
            let velocidadEnCadena = "Velocidad Alta!, ALTO! frena!"
            
            let resultado = (Velocidades.VelocidadAlta.rawValue , velocidadEnCadena)
             
            print(resultado)
            
            return resultado
            
        
        }
        
        //Case = 120
        if  vel == Velocidades.VelocidadAlta {
            
            vel.rawValue == Velocidades.VelocidadMedia.rawValue
            
            let velocidadEnCadena = "Velocidad Media, gracias por frenar un poco, la seguridad ante todo!"
            
            let resultado = (Velocidades.VelocidadMedia.rawValue , velocidadEnCadena)
            
            print(resultado)
            
            return resultado
            
            
        }
        else{
            
            let mensaje : String = "no encontrado, vuelvelo a introducir por favor"
            
            let resultado = (vel.rawValue , mensaje)
            
            print(resultado)

            return resultado
            
        }
  }

}


var test = [Velocidades.Apagado,Velocidades.VelocidadBaja,Velocidades.VelocidadMedia,Velocidades.VelocidadAlta,Velocidades.VelocidadMedia,Velocidades.Apagado,Velocidades.VelocidadBaja,Velocidades.VelocidadMedia, Velocidades.VelocidadMedia,Velocidades.VelocidadAlta,Velocidades.VelocidadBaja,Velocidades.VelocidadBaja,Velocidades.Apagado,Velocidades.VelocidadBaja,Velocidades.VelocidadMedia,Velocidades.VelocidadAlta,Velocidades.Apagado,Velocidades.VelocidadBaja,Velocidades.VelocidadMedia,Velocidades.VelocidadAlta]

var velocity = Auto.init(velocidad: Velocidades.VelocidadBaja)
for v in test{
    
     velocity.cambioDeVelocidad(vel: v)
   
}

//velocity.cambioDeVelocidad(vel: Velocidades.VelocidadBaja)

